function registerUser() {
    const username = document.getElementById("register-username").value;
    const password = document.getElementById("register-password").value;
  
    if (username && password) {
      localStorage.setItem("user", JSON.stringify({ username, password }));
      alert("Registered successfully! Now login.");
      window.location.href = "login.html";
    } else {
      alert("Please fill in all fields.");
    }
    return false;
  }
  
  function loginUser() {
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;
  
    const savedUser = JSON.parse(localStorage.getItem("user"));
  
    if (savedUser && username === savedUser.username && password === savedUser.password) {
      alert("Login successful!");
      window.location.href = "index.html"; // Redirect to main perfume page
    } else {
      alert("Invalid username or password.");
    }
    return false;
  }
  